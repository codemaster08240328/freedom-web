export const bankNames = [
  "ABSA",
  "Standard Bank",
  "Nedbank",
  "FNB",
  "Capitec"
]