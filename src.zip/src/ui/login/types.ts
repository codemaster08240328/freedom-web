export interface ILoginCredentials {
  password: string;
  email: string;
}