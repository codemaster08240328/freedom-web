export interface ITab {
  id: string,
  title: string,
}

export type TabList = ITab[];