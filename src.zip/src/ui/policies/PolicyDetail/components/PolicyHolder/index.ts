import PolicyHolder from './PolicyHolder';

export default PolicyHolder;