import PaymentInfoView from './PaymentInfo.view';

export default PaymentInfoView;