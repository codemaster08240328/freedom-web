import NotesCard from './NotesCard';
export default NotesCard;
