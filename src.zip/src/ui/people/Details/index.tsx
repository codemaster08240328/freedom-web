import DetailsView from './Details';

export default DetailsView;