import PeopleTabView from './PeopleTabView';
import PeopleStore from './store';

export {
  PeopleTabView,
  PeopleStore
};