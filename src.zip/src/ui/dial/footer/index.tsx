import FooterView from './Footer.view';

export default FooterView;
