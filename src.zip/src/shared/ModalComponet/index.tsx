import ModalComponent from './ModalComponet';
export default ModalComponent;
