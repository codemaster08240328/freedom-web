import PopoversComponent from './PopoversComponent';
export default PopoversComponent;
