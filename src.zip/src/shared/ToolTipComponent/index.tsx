import ToolTipComponent from './ToolTipComponent';
export default ToolTipComponent;
