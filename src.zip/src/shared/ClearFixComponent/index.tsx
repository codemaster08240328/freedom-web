import ClearFixComponent from './ClearFixComponent';
export default ClearFixComponent;
