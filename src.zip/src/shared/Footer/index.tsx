import FooterUI from './FooterUI';

export default FooterUI;
