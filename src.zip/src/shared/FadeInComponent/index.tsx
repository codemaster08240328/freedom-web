import FadeInComponent from './FadeInComponent';
export default FadeInComponent;
