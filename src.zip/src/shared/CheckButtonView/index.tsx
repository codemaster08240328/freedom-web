import CheckButtonView from './CheckButtonView';
export default CheckButtonView;
