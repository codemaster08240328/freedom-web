import TitleWithShadow from './TitleWithShadow';

export default TitleWithShadow;