import CardComponent from './CardComponent';
export default CardComponent;
