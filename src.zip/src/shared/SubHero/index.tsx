import SubHeroUI from './SubHeroUI';
export default SubHeroUI;
