import ReadMoreView from './ReadMoreView';
export default ReadMoreView;
