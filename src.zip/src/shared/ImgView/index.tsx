import { Img } from './ImgView';
export { Img };