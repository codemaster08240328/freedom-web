import PageTileView from './PageTileView';
export default PageTileView;
