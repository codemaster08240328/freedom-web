import WizardStepperView from './WizardStepperView';
export default WizardStepperView;
