import NotificationContainer from './Container';

export default NotificationContainer;