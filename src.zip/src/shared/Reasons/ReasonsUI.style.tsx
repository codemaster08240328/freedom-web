import styled from 'styled-components';

export const ReasonsContainer = styled.section`
padding: 0 0 60px;
`;
